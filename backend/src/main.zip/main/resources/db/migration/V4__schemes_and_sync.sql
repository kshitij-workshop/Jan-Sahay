-- V4__schemes_and_sync.sql
-- Government scheme catalog (normalized core + preserved raw JSON) and
-- synchronization bookkeeping. All myScheme-sourced text is nullable:
-- normalization is best-effort and must never invent data.

CREATE TABLE schemes (
    id CHAR(36) NOT NULL PRIMARY KEY,
    slug VARCHAR(255) NOT NULL,
    scheme_name VARCHAR(500),
    scheme_name_eng VARCHAR(500),
    short_title VARCHAR(255),
    scheme_category VARCHAR(255),
    beneficiary_state VARCHAR(255),
    level VARCHAR(50),
    scheme_for VARCHAR(255),
    nodal_ministry VARCHAR(500),
    brief_description TEXT,
    brief_description_eng TEXT,
    close_date VARCHAR(50),
    priority INT NULL,
    source VARCHAR(50) NOT NULL DEFAULT 'MYSCHEME',
    source_url VARCHAR(1000),
    last_synced_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_schemes_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_schemes_category ON schemes(scheme_category);
CREATE INDEX idx_schemes_state ON schemes(beneficiary_state);
CREATE INDEX idx_schemes_level ON schemes(level);

CREATE TABLE scheme_raw_data (
    scheme_id CHAR(36) NOT NULL PRIMARY KEY,
    slug VARCHAR(255) NOT NULL,
    kind VARCHAR(30) NOT NULL DEFAULT 'DETAIL',
    payload JSON NOT NULL,
    fetched_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_raw_scheme FOREIGN KEY (scheme_id) REFERENCES schemes (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_raw_slug ON scheme_raw_data(slug);

CREATE TABLE scheme_tags (
    id CHAR(36) NOT NULL PRIMARY KEY,
    scheme_id CHAR(36) NOT NULL,
    tag VARCHAR(255) NOT NULL,
    language VARCHAR(10) NOT NULL DEFAULT 'en',
    CONSTRAINT fk_tags_scheme FOREIGN KEY (scheme_id) REFERENCES schemes (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_tags_scheme ON scheme_tags(scheme_id);

CREATE TABLE scheme_states (
    id CHAR(36) NOT NULL PRIMARY KEY,
    scheme_id CHAR(36) NOT NULL,
    state VARCHAR(100) NOT NULL,
    CONSTRAINT fk_states_scheme FOREIGN KEY (scheme_id) REFERENCES schemes (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_states_scheme ON scheme_states(scheme_id);

CREATE TABLE scheme_faqs (
    id CHAR(36) NOT NULL PRIMARY KEY,
    scheme_id CHAR(36) NOT NULL,
    question TEXT NOT NULL,
    answer TEXT,
    language VARCHAR(10) NOT NULL DEFAULT 'en',
    position INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_faqs_scheme FOREIGN KEY (scheme_id) REFERENCES schemes (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_faqs_scheme ON scheme_faqs(scheme_id);

CREATE TABLE scheme_documents (
    id CHAR(36) NOT NULL PRIMARY KEY,
    scheme_id CHAR(36) NOT NULL,
    name VARCHAR(500) NOT NULL,
    required BOOLEAN NOT NULL DEFAULT TRUE,
    language VARCHAR(10) NOT NULL DEFAULT 'en',
    position INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_documents_scheme FOREIGN KEY (scheme_id) REFERENCES schemes (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_documents_scheme ON scheme_documents(scheme_id);

CREATE TABLE scheme_application_process (
    id CHAR(36) NOT NULL PRIMARY KEY,
    scheme_id CHAR(36) NOT NULL,
    step_no INT NOT NULL,
    description TEXT NOT NULL,
    language VARCHAR(10) NOT NULL DEFAULT 'en',
    CONSTRAINT fk_process_scheme FOREIGN KEY (scheme_id) REFERENCES schemes (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_process_scheme ON scheme_application_process(scheme_id);

CREATE TABLE sync_jobs (
    id CHAR(36) NOT NULL PRIMARY KEY,
    status VARCHAR(20) NOT NULL,
    from_offset INT NOT NULL DEFAULT 0,
    requested_limit INT NOT NULL DEFAULT 0,
    fetched INT NOT NULL DEFAULT 0,
    created_count INT NOT NULL DEFAULT 0,
    updated_count INT NOT NULL DEFAULT 0,
    failed_count INT NOT NULL DEFAULT 0,
    error_message VARCHAR(1000),
    started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finished_at TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sync_errors (
    id CHAR(36) NOT NULL PRIMARY KEY,
    job_id CHAR(36) NOT NULL,
    slug VARCHAR(255),
    stage VARCHAR(50) NOT NULL,
    message VARCHAR(1000) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sync_errors_job FOREIGN KEY (job_id) REFERENCES sync_jobs (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_sync_errors_job ON sync_errors(job_id);
