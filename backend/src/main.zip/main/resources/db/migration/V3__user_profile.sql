-- V3__user_profile.sql
-- User profile (1-1 with users) + addresses (1-N).
-- Enums stored as VARCHAR (not MySQL ENUM) so new categories never require DDL.
-- additional_attributes is a JSON escape hatch for future scheme criteria
-- without rewriting the schema.

CREATE TABLE user_profiles (
    user_id CHAR(36) NOT NULL PRIMARY KEY,
    full_name VARCHAR(255),
    date_of_birth DATE NULL,
    gender VARCHAR(20),
    nationality VARCHAR(100) NOT NULL DEFAULT 'Indian',
    education_level VARCHAR(40),
    institution VARCHAR(255),
    student_status BOOLEAN NULL,
    course VARCHAR(255),
    annual_income BIGINT NULL,
    income_category VARCHAR(40),
    bpl_status BOOLEAN NULL,
    economic_distress BOOLEAN NULL,
    caste_category VARCHAR(20),
    minority_status BOOLEAN NULL,
    disability_status BOOLEAN NULL,
    disability_percentage INT NULL,
    occupation VARCHAR(40),
    employment_status VARCHAR(40),
    govt_employee BOOLEAN NULL,
    marital_status VARCHAR(20),
    dependents INT NULL,
    additional_attributes JSON NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_profiles_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE user_addresses (
    id CHAR(36) NOT NULL PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    address_type VARCHAR(20) NOT NULL DEFAULT 'PERMANENT',
    is_primary BOOLEAN NOT NULL DEFAULT FALSE,
    state VARCHAR(100),
    district VARCHAR(100),
    block VARCHAR(100),
    village_town VARCHAR(255),
    pincode VARCHAR(10),
    area_type VARCHAR(20),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_addresses_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_addresses_user ON user_addresses(user_id);
CREATE INDEX idx_addresses_state_district ON user_addresses(state, district);
CREATE INDEX idx_profiles_caste ON user_profiles(caste_category);
CREATE INDEX idx_profiles_occupation ON user_profiles(occupation);
