-- V2__add_email_verification_token.sql
-- Add email verification token columns to users table

ALTER TABLE users 
ADD COLUMN email_verification_token VARCHAR(255),
ADD COLUMN email_verification_token_expiry TIMESTAMP NULL;

CREATE INDEX idx_users_email_verification_token ON users(email_verification_token);